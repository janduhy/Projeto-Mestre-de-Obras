package jframe.ouvintes;

public class Ouvinte {

}
