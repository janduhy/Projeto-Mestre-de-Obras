package jframe.componentes;

public class Botao {

}
